import React from 'react'
import './chatbotstart.css'
const chatbotstart = ({onStartChat}) => {
  return (
    <div className ='start-page'>
   <button className="start-page-btn" onClick={onStartChat}>AI chat</button>
    </div>
  )
}
export default chatbotstart